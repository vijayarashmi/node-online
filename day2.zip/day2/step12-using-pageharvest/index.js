let ph = require("pageharvest");

ph.fetchThatUrl("http://ukorthocare.com","orthocare.html");
