var express = require("express");
var fs = require("fs");

var app = express();

// ----------------------------
app.set("view engine", "pug");
// app.use(express.urlencoded({ extended : true })); 
app.use(express.urlencoded());
var rawData = null;
var heroes = null;
//--------------------
app
.get("/",function(req, res){
    rawData = fs.readFileSync("data/heroes.json","utf-8");
    heroes = JSON.parse(rawData).data;
    res.render("home",{
        title : "My Company",
        herolist : heroes
    })
})
.post("/",function(req, res){
    // console.log(req.body.newhero);
    heroes.push(req.body.newhero);
    let writeData = {
        "data" : heroes
    }
    fs.writeFileSync("data/heroes.json",JSON.stringify(writeData));
    res.redirect("/");
    res.end();
});

app.listen(3030,"localhost",function(error){
    if(error){ console.log("Error : ", error)}
    else{ console.log("Server is now running on localhost:3030")}
})