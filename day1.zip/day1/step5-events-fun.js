let EventEmitter = require("events").EventEmitter;

let myevent = new EventEmitter();

/* myevent.on("onlineEvent", function(evt,msg){
    console.log(evt.type+" happened", evt.message, evt.power, evt.city, msg);
}); */

/* setTimeout(function(){
    let evtObj = {
        message : "My Custom Message",
        power : 6,
        city : "Gotham",
        type : "onlineEvent"
    }
    myevent.emit("onlineEvent",evtObjs);
},1000); */

let count = 0;
myevent.on("onlineEvent", function(){
    console.log("onlineEvent happened");
});

let si = setInterval(function(){
    if(count < 5){
        myevent.emit("onlineEvent");
        count++;
    }else{
        clearInterval(si);
        console.log("interval stopped");
    }
},2000);