let EventEmitter = require("events").EventEmitter;

class HeroList extends EventEmitter{
	list = [];
    add(heroname){
        this.list.push(heroname);
        this.emit("heroAddedEvent", heroname);
    }
}

var list = new HeroList();

list.on("heroAddedEvent", function(hname){
	console.log("hello", hname);
});

list.add("Batman");
list.add("Ironman");