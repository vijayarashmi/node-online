require("./global-config");

console.log(companyname);
// console.log(cities.length);
cities.forEach(function(val){
    console.log("Current City : ",val);
});
