var firstname = "vijay";
var lastname = "shivakumar";
function fullname(fn, ln){
    return fn+" "+ln;
};
// console.log(fullname(firstname, lastname));
// console.log(module.exports);
/* 
module.exports.one = "prop 1";
module.exports.two = "prop 2"; 
*/
// destructuring
module.exports = { firstname,lastname,fullname };