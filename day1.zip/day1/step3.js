var one = require("./step2");
// console.log(one.one, one.two);
// console.log(one.fname, one.lname);
console.log(one.firstname);
console.log(one.lastname);
console.log(one.fullname("Bruce","Wayne"));