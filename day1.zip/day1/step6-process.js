// console.log(process.argv[2].toUpperCase());
console.log(process.env.USERNAME);