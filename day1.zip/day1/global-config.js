global.companyname = "My Company Name";
global.cities = ['Bangalore', 'Delhi','New York','Barcelona'];